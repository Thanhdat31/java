package baitaplab2;
//bai 1
import java.util.Scanner;

public class baitap {
     public static void main(String[] args) {
    	 int a,b;
		Scanner sc = new Scanner(System.in); 
		System.out.println("nhap a : ");
		a = sc.nextInt();
		System.out.println("nhap b : ");
		b = sc.nextInt();
		if (a==0) {
			if (b==0) {
				System.out.println("phuong trinh vo so nghiem");	
			}else {
				System.out.println("phuong trinh vo nghiem");
			}
		}else {
			float x = (float) -b/a ;
			System.out.println("phuong trinh co mot nghiem duy nhat :"+x);
		}	
	}
}


