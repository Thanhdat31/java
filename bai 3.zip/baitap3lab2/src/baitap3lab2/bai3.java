package baitap3lab2;

import java.util.Scanner;

public class bai3 {
    public static void main(String[] args) {
		float n,tiendien;
		Scanner sc = new Scanner(System.in);
		System.out.println("nhập số điện đã sử dụng =");
		n = sc.nextFloat();
		if (n<50)
			tiendien = n*1000;
		else 
			tiendien = 50*1000+(n-50)*1200;
		System.out.println("số tiền điện phải trả ="+ tiendien);
		}
}
